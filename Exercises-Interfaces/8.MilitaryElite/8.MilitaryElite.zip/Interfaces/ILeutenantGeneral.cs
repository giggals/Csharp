﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ILeutenantGeneral
{
    List<Private> Privates { get; set; }
}

