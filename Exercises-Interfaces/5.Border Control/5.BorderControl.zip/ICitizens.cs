﻿using System;
using System.Collections.Generic;
using System.Text;


public interface ICitizens
{
    string PersonName {get;}
    int Age { get; }
    string IdPerson { get; }
}

