﻿using System;
using System.Collections.Generic;
using System.Text;


public interface IRobots
{
    string Model { get; }
    string IdRobot { get; }
}

