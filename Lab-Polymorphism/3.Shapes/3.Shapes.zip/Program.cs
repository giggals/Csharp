﻿using System;

namespace _3.Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
