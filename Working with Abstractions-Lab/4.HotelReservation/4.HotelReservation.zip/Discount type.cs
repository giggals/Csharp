﻿using System;
using System.Collections.Generic;
using System.Text;

public enum Discount_type
{
    noDiscount = 0,
    SecondVisit = 10,
    VIP = 20
}

